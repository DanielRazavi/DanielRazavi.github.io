import random
from argparse import ArgumentParser
from simulator import Simulator
from state import *
from probability import *
from agents import MarkovAgent, ParticleAgent
from grade_helpers import load_test, convert_solution
import signal

SCALE_FACTOR = 15 # DO NOT ALTER
WAIT_TIME = 0.2
VERBOSE = False

# These can 100% be written as one, but to keep things easy to understand and
# simplicitic we keep them as below

def particle_reset_test(simulator, state, solution):
  # Don't actually need simulator for this test
  # To make our lives simple we will match the maps open tiles (for divisibility purposes) when giving a particle count

  valid_positions = GameStateHandler(state).get_valid_positions()
  grid = ParticleGrid(valid_positions, len(valid_positions) * SCALE_FACTOR)

  particle_dist = grid.get_particle_distribution()

  # Mess up the distribution
  for key in particle_dist:
    particle_dist[key] = random.random()

  # Reset the distribution
  grid.reset()

  return grid.get_particle_distribution() == convert_solution(solution)

def particle_reweight_test(simulator, state, solution):
  # Don't actually need simulator for this test
  # To make our lives simple we will match the maps open tiles (for divisibility purposes) when giving a particle count

  valid_positions = GameStateHandler(state).get_valid_positions()
  grid = ParticleGrid(valid_positions, len(valid_positions) * SCALE_FACTOR)


  # Generate a random distribution
  dist = { key:random.random() for key in grid.get_particle_distribution() }

  # Reweight the particles
  grid.reweight_particles(dist)

  return grid.get_particle_distribution() == convert_solution(solution)

def test(tests, tester):

  def signal_handler(signum, frame):
    raise Exception("Timed out")

  total_marks, earned_marks = 0, 0

  for test in tests:
    name, map_file, seed, solution = load_test(test)

    signal.signal(signal.SIGALRM, signal_handler)
    signal.alarm(120)

    total_marks += 1

    try:
      # Run the test
      state = GameState(map_file)
      random.seed(seed)

      sim = Simulator(map_file, WAIT_TIME)
      sim.verbose(VERBOSE)

      result = tester(sim, state, solution)
      earned = int(result)
      print("Testing: {}\t [{}/{}]".format(name, earned, 1))

      earned_marks += earned

    except Exception as e:
      print("Testing {}\t [{}]\t [0/1]".format(name, e))

  return earned_marks, total_marks

if __name__ == "__main__":
  parser = ArgumentParser(description = "Running Autograder for Assignment 4")
  parser.add_argument("-v", "--verbose", help = "Displays the actions the agent is taking during the simulation",
                      required = False, default = "")
  parser.add_argument("-w", "--waitTime", type = float,
                      help = "How long the simulation waits before taking another action", required = False, default=0.1)

  # Setting up based on arguments
  args = parser.parse_args()
  VERBOSE = args.verbose
  if args.waitTime :
    WAIT_TIME = args.waitTime

  # Start the tests
  total_marks, earned_marks = 0, 0

  print("\n------ Question 3 ------")
  e, t = test(["particles/open_test", "particles/entity_test"], particle_reset_test)
  total_marks += t
  earned_marks += e

  print("\n------ Question 4 ------")
  e, t = test(["particles/weight_test", "particles/weight_test_2"], particle_reweight_test)
  total_marks += t
  earned_marks += e

  print("\n\nTotal Grade - PG: {}/{}".format(earned_marks, total_marks))
