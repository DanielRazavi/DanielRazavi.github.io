#!/bin/bash

dir=$(dirname $(readlink -f $0))

# Making sure a parameter is passed in.
if [ -z $1 ]; then
	echo "you need to pass a utorid/groupid as the parameter."
	exit 1
fi

student="$1"

# Checking to see if the utorid/groupid directory exists in the handed in assignments.
if [ ! -d "${dir}/student_solutions/$student" ]; then
	echo "student utorid does not exist."
	exit 1
fi

# Deleting old text file.
echo "deleted old mark."
rm -f "${dir}/student_marks/$student-autograder-mark.txt"

echo "Marking \"$student\""

echo "Making independent environment."
mkdir -p "${dir}/student_solution_envs/${student}-student-marking-env"
cp -r "${dir}/a4_starter/"* "${dir}/student_solution_envs/${student}-student-marking-env/"

# Deleting Original Files From Environment
rm -f "${dir}/student_solution_envs/${student}-student-marking-env/agents/markov_agent.py"
rm -f "${dir}/student_solution_envs/${student}-student-marking-env/agents/particle_agent.py"
rm -f "${dir}/student_solution_envs/${student}-student-marking-env/probability/particle_grid.py"

# markov_agent testing.
echo "\"${student}\": Running tests on \"markov_agent.py\"."
if [ -e "${dir}/student_solutions/${student}/markov_agent.py" ];then
	cp -r "${dir}/student_solutions/${student}/markov_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
else
	cp -r "${dir}/blanks/markov_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
fi

cp -r "${dir}/perfects/particle_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
cp -r "${dir}/perfects/particle_grid.py" "${dir}/student_solution_envs/${student}-student-marking-env/probability/"

cd "${dir}/student_solution_envs/${student}-student-marking-env/"
echo "\"${student}\": started ma test at $(date)"
ma_output=$(timeout 600 python3.7 "autograder_ma.py" 2>&1)
cd "${dir}"
ma_mark=$(echo "${ma_output}" | grep "Total Grade - MA:" | cut -d " " -f5)
ma_output=$(echo "${ma_output}" | grep -v "Total Grade - MA:")


# particle_agent testing.
echo "\"${student}\": Running tests on \"particle_agent.py\"."
if [ -e "${dir}/student_solutions/${student}/particle_agent.py" ];then
	cp -r "${dir}/student_solutions/${student}/particle_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
else
	cp -r "${dir}/blanks/particle_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
fi

cp -r "${dir}/perfects/markov_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
cp -r "${dir}/perfects/particle_grid.py" "${dir}/student_solution_envs/${student}-student-marking-env/probability/"

cd "${dir}/student_solution_envs/${student}-student-marking-env/"
echo "\"${student}\": started pa test at $(date)"
pa_output=$(timeout 600 python3.7 "autograder_pa.py" 2>&1)
cd "${dir}"
pa_mark=$(echo "${pa_output}" | grep "Total Grade - PA:" | cut -d " " -f5)
pa_output=$(echo "${pa_output}" | grep -v "Total Grade - PA:")


# particle_grid testing.
echo "\"${student}\": Running tests on \"particle_grid.py\"."
if [ -e "${dir}/student_solutions/${student}/particle_grid.py" ];then
	cp -r "${dir}/student_solutions/${student}/particle_grid.py" "${dir}/student_solution_envs/${student}-student-marking-env/probability/"
else
	cp -r "${dir}/blanks/particle_grid.py" "${dir}/student_solution_envs/${student}-student-marking-env/probability/"
fi

cp -r "${dir}/perfects/markov_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"
cp -r "${dir}/perfects/particle_agent.py" "${dir}/student_solution_envs/${student}-student-marking-env/agents/"

cd "${dir}/student_solution_envs/${student}-student-marking-env/"
echo "\"${student}\": started pg test at $(date)"
pg_output=$(timeout 600 python3.7 "autograder_pg.py" 2>&1)
cd "${dir}"
pg_mark=$(echo "${pg_output}" | grep "Total Grade - PG:" | cut -d " " -f5)
pg_output=$(echo "${pg_output}" | grep -v "Total Grade - PG:")



# Final Mark Calculations
numerator=$(echo "$(echo ${ma_mark} | cut -d"/" -f1) + $(echo ${pa_mark} | cut -d"/" -f1) + $(echo ${pg_mark} | cut -d"/" -f1)" | bc)
denominator=$(echo "$(echo ${ma_mark} | cut -d"/" -f2) + $(echo ${pa_mark} | cut -d"/" -f2) + $(echo ${pg_mark} | cut -d"/" -f2)" | bc)
total_mark="Total Grade: ${numerator}/${denominator}"

echo "Documenting student mark."
echo -e "${ma_output}\n${pa_output}\n${pg_output}\n\n${total_mark}" > "${dir}/student_marks/${student}-autograder-mark.txt"

rm -rf 	"${dir}/student_solution_envs/${student}-student-marking-env"
rm -rf "${dir}/student_solution_envs"

echo "Marking Done."
