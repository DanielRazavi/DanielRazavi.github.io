TILESIZE = 32
ASSETS = ["assets/player.gif", "assets/box.gif", "assets/armory_point.gif", "assets/monster.gif", "assets/mouse.gif"]
PLAYER_IMAGE_REF = 0
BOX_IMAGE_REF = 1
ARMORY_POINT_IMAGE_REF = 2
MONSTER_IMAGE_REF = 3
MOUSE_IMAGE_REF = 4
