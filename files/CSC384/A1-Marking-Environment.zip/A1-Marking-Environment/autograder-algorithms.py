from state import GameState, GameStateHandler
from state_searching import *
from grade_helpers import load_test, verify, pseudo_simulate, check_solution
import signal

COST_FUNCTIONS = [lambda pos : 0.2 ** pos[0], lambda pos : pos[0] * 2, lambda pos : pos[1] * 2, lambda pos :  pos[1] * 2 + 0.2 ** pos[0]]


def test(tests, tester):

  def signal_handler(signum, frame):
    raise Exception("Timed out!")

  total_marks, earned_marks = 0, 0

  for test in tests:
    name, map_file, goal_func, solution, visited, seen = load_test(test)

    total_marks += 1
    signal.signal(signal.SIGALRM, signal_handler)
    signal.alarm(30)

    try:
      state = GameState(map_file)

      result = tester(goal_func, state, solution, visited, seen)

      earned = int(result)
      print("Testing: {}\t [{}/{}]".format(name, earned, 1))

      earned_marks += earned
    except NotImplementedError as e:
      print("Testing: {}\t [{}]\t [0/1]".format(name, e))
    except Exception:
      print("Testing: {}\t [Timed Out]\t [0/1]".format(name))
  return earned_marks, total_marks

if __name__ == "__main__":
  total_marks, earned_marks = 0, 0

  print("------ Question 1 ------")

  e, t = test(["dfs/basic_1b", "dfs/basic_b", "dfs/basic_p", "dfs/best_basic_dfs","dfs/worst_basic_dfs"], lambda goal, state, solution, visited, seen : check_solution(goal, state, solution, visited, seen, SearchAlgorithms.depth_first_search(goal, state)))

  total_marks += t
  earned_marks += e

  print("\n------ Question 2 ------")

  e, t = test(["bfs/basic_1b", "bfs/basic_b", "bfs/basic_p", "bfs/worst_basic_bfs", "bfs/best_basic_bfs"], lambda goal, state, solution, visited, seen : check_solution(goal, state, solution, visited, seen, SearchAlgorithms.breadth_first_search(goal, state)))

  total_marks += t
  earned_marks += e

  print("\n------ Question 3 ------")

  for i in range(len(COST_FUNCTIONS)):

    e, t = test(["ucs/multiple_paths_with_func{}".format(i + 1)], lambda goal, state, solution, visited, seen : check_solution(goal, state, solution, visited, seen, SearchAlgorithms.uniform_cost_search(goal, state, cost_fn = COST_FUNCTIONS[i])))

    total_marks += t
    earned_marks += e

  print("\n------ Question 4 ------")

  for i in range(len(COST_FUNCTIONS)):

    e, t = test(["ucs/multiple_paths_with_func{}".format(i + 1)], lambda goal, state, solution, visited, seen : check_solution(goal, state, solution, visited, seen, SearchAlgorithms.a_star_search(goal, state, cost_fn = COST_FUNCTIONS[i])))

    total_marks += t
    earned_marks += e

  print("\n\nTotal Grade - Algorithms: {}/{}".format(earned_marks, total_marks))
