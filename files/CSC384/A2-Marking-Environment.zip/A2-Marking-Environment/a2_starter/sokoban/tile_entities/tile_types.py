from enum import Enum

class TileType(Enum):

  SIMPLE = "simple"
  WALL = "wall"
  SWITCH = "switch"
