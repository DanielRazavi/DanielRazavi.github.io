from csp import TetrisCSP, CSPAlgorithms, CSPUtil
from grade_helpers import load_test, verify_domain, assign_variables, create_solution, create_solution_inverse
import signal

CREATING_SOLUTIONS = False
IN_DEPTH_MARKING = False


def test_algorithm(algo, csp, solution, unassigned_history):
    sol = algo(csp)
    marks = int(sol == create_solution(csp.variables(), solution)) + \
        int(csp.unassigned_history() == unassigned_history)
    if IN_DEPTH_MARKING:
        marks = int(sol == create_solution(csp.variables(), solution)) + \
            int(csp.unassigned_history() == unassigned_history)
    else:
        marks = int(sol == create_solution(csp.variables(), solution)) * 2

    if CREATING_SOLUTIONS:
        return marks/2, create_solution_inverse(csp.variables(), sol), csp.unassigned_history()
    else:
        return marks/2

def test(tests, tester):

    def signal_handler(signum, frame):
        raise Exception("Timed out")

    total_marks, earned_marks = 0, 0

    for test in tests:
        name, grid, variables, solution, pass_expected, extra_expected = load_test(
            test)

        signal.signal(signal.SIGALRM, signal_handler)
        signal.alarm(120)

        csp = TetrisCSP(grid)

        total_marks += 1.0

        try:
            # Run the test
            csp.initialize_variables(variables)

            if CREATING_SOLUTIONS:
                result, solution, assignments = tester(
                    csp, solution, extra_expected)
                print(solution)
                print(assignments)
            else:
                result = tester(csp, solution, extra_expected) if pass_expected else not tester(
                    csp, solution, extra_expected)

            earned = float(result)
            print("Testing: {}\t [{}/{}]".format(name, earned, 1.0))

            earned_marks += earned

        except Exception as e:
            print("Testing {}\t [{}]\t [0/1.0]".format(name, e))

    return earned_marks, float(total_marks)


if __name__ == "__main__":
    total_marks, earned_marks = 0, 0

    print("\n------ Question 3 ------")
    e, t = test(["q3/unique", "q3/var-iot", "q3/var-joti", "q3/var-lit", "q3/var-ljtz"], lambda csp, solution, unsassigned_history: test_algorithm(
        CSPAlgorithms.backtracking, csp, solution, unsassigned_history))  # 324 coming in handy
    total_marks += t
    earned_marks += e

    print("\n------ Question 4 ------")
    e, t = test(["q4/unique", "q4/var-iot", "q4/var-joti", "q4/var-lit", "q4/var-ljtz"], lambda csp, solution, unsassigned_history: test_algorithm(
        CSPAlgorithms.forward_checking, csp, solution, unsassigned_history))  # 324 coming in handy
    total_marks += t
    earned_marks += e

    print("\n------ Question 6 ------")
    e, t = test(["q6/unique", "q6/var-iot", "q6/var-joti", "q6/var-lit", "q6/var-ljtz"], lambda csp, solution, unsassigned_history: test_algorithm(
        CSPAlgorithms.gac, csp, solution, unsassigned_history))  # 324 coming in handy
    total_marks += t
    earned_marks += e

    print("\n\nTotal Grade - CA: {}/{}".format(earned_marks, total_marks))
