from argparse import ArgumentParser
import json

def grid_to_json(input_file: str):
  info = {}
  info["grid"] = []
  
  with open("{}.grid".format(input_file), "r") as f:
    for line in f:
      row = []
      values = line.strip().split(",")
      for v in values:
        row.append(int(v))
        
      info["grid"].append(row)

  info["rows"] = len(info["grid"])
  info["cols"] = len(info["grid"][0])
      
  with open("{}.json".format(input_file), "w") as f:
    json.dump(info, f)
    
if __name__ == "__main__":

  parser = ArgumentParser()

  parser.add_argument("-g", "--grid", help="Grid to run on", type=str)

  args = parser.parse_args()
  
  grid_to_json("assets/grids/{}".format(args.grid))
