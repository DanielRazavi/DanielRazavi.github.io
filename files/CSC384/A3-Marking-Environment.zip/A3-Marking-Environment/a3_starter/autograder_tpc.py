from csp import TetrisCSP, CSPAlgorithms, CSPUtil
from grade_helpers import load_test, verify_domain, assign_variables, create_solution, create_solution_inverse


CREATING_SOLUTIONS = False

def test_constraint(csp, solution, _):
    assign_variables(csp, csp.variables(), solution)

    for constraint in csp.constraints():
        if not constraint.check(csp.variables(), csp.assignments()):
            return False

    return True

def test_future_check(csp, solution, _):
    var, val = csp.variables()[solution[0]], solution[1]

    for constraint in csp.constraints():
        if not constraint.has_future(csp, var, val):
            return False

    return True


def test(tests, tester):
    total_marks, earned_marks = 0, 0

    for test in tests:
        name, grid, variables, solution, pass_expected, extra_expected = load_test(
            test)
        csp = TetrisCSP(grid)

        total_marks += 1.0

        try:
            # Run the test
            csp.initialize_variables(variables)

            if CREATING_SOLUTIONS:
                result, solution, assignments = tester(
                    csp, solution, extra_expected)
                print(solution)
                print(assignments)
            else:
                result = tester(csp, solution, extra_expected) if pass_expected else not tester(
                    csp, solution, extra_expected)

            earned = float(result)
            print("Testing: {}\t [{}/{}]".format(name, earned, 1.0))

            earned_marks += earned

        except Exception as e:
            print("Testing {}\t [{}]\t [0/1.0]".format(name, e))

    return earned_marks, float(total_marks)


if __name__ == "__main__":
    total_marks, earned_marks = 0, 0

    print("\n------ Question 2 ------")
    e, t = test(["q2/simple", "q2/incorrect", "q2/multiple_olz","q2/multiple_tsi","q2/double_pass", "q2/double_fail"], test_constraint)
    total_marks += t
    earned_marks += e


    print("\n------ Question 5 ------")
    e, t = test(["q5/future_check_1","q5/future_check_2","q5/future_check_3","q5/no_future_1","q5/no_future_2","q5/no_future_3"], test_future_check)
    total_marks += t
    earned_marks += e


    print("\n\nTotal Grade - TPC: {}/{}".format(earned_marks, total_marks))
