# tetris-csp
Assignment 3 for CSC384 featuring a the classic game Tetris written in Python 3
