ASSETS = ["assets/open.gif", "assets/s.gif", "assets/z.gif", "assets/l.gif", "assets/j.gif", "assets/o.gif", "assets/i.gif", "assets/t.gif"]
LINE_LIMIT = 4
TETROMINO_GRID_SIZE = 4
TILESIZE = 32
BORDER = 5
