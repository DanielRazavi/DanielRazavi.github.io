from csp import TetrisCSP, CSPAlgorithms, CSPUtil
from grade_helpers import load_test, verify_domain, assign_variables, create_solution, create_solution_inverse


CREATING_SOLUTIONS = False


def test_domain(csp, solution, _):
    if CREATING_SOLUTIONS:
        my_list = [var.domain() for var in csp.variables()]
        return True, my_list
    else:
        return verify_domain(sorted([var.domain() for var in csp.variables()]), sorted(solution))


def test(tests, tester):
    total_marks, earned_marks = 0, 0

    for test in tests:
        name, grid, variables, solution, pass_expected, extra_expected = load_test(
            test)
        csp = TetrisCSP(grid)

        total_marks += 1.0

        try:
            # Run the test
            csp.initialize_variables(variables)

            if CREATING_SOLUTIONS:
                result, solution, assignments = tester(
                    csp, solution, extra_expected)
                print(solution)
                print(assignments)
            else:
                result = tester(csp, solution, extra_expected) if pass_expected else not tester(
                    csp, solution, extra_expected)

            earned = float(result)
            print("Testing: {}\t [{}/{}]".format(name, earned, 1.0))

            earned_marks += earned

        except Exception as e:
            print("Testing {}\t [{}]\t [0/1.0]".format(name, e))

    return earned_marks, float(total_marks)


if __name__ == "__main__":
    total_marks, earned_marks = 0, 0

    print("------ Question 1 ------")
    e, t = test(["q1/simple_i", "q1/simple_j", "q1/simple_l", "q1/simple_o",
                 "q1/simple_s", "q1/simple_t", "q1/simple_z"], test_domain)
    total_marks += t
    earned_marks += e

    print("\n\nTotal Grade - TC: {}/{}".format(earned_marks, total_marks))
