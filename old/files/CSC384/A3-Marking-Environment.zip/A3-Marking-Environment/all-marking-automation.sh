#!/bin/bash

dir=$(dirname $(readlink -f $0))

rm -f "${dir}/student_marks/"*
echo "deleted old marks."

mkdir "${dir}/student_solution_envs"

pids=""

for student in  $(ls "${dir}/student_solutions");do

	(echo "\"${student}\": Marking..."

	# Setting up Marking Environment.
	echo "\"${student}\": Making independent environment."
	mkdir "${dir}/student_solution_envs/${student}-student-marking-env"
	cp -r "${dir}/a3_starter/"* "${dir}/student_solution_envs/${student}-student-marking-env/"

	rm -f "${dir}/student_solution_envs/${student}-student-marking-env/csp/csp_algorithms.py"
	rm -f "${dir}/student_solution_envs/${student}-student-marking-env/csp/tetris_csp.py"
	rm -f "${dir}/student_solution_envs/${student}-student-marking-env/csp/tetromino_puzzle_constraint.py"


	# csp_algorithms testing.
	echo "\"${student}\": Running tests on \"csp_algorithms.py\"."
	if [ -e "${dir}/student_solutions/${student}/csp_algorithms.py" ];then
		cp -r "${dir}/student_solutions/${student}/csp_algorithms.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	else
		cp -r "${dir}/blanks/csp_algorithms.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	fi

	cp -r "${dir}/perfects/tetris_csp.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	cp -r "${dir}/perfects/tetromino_puzzle_constraint.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"

	cd "${dir}/student_solution_envs/${student}-student-marking-env/"
	echo "\"${student}\": started ca test at $(date)"
	ca_output=$(timeout 900 python3 "autograder_ca.py" 2>&1)
	cd "${dir}"
	ca_mark=$(echo "${ca_output}" | grep "Total Grade - CA:" | cut -d " " -f5)
	ca_output=$(echo "${ca_output}" | grep -v "Total Grade - CA:")


	# tetris_csp testing.
	echo "\"${student}\": Running tests on \"tetris_csp.py\"."
	if [ -e "${dir}/student_solutions/${student}/tetris_csp.py" ];then
		cp -r "${dir}/student_solutions/${student}/tetris_csp.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	else
		cp -r "${dir}/blanks/tetris_csp.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	fi

	cp -r "${dir}/perfects/csp_algorithms.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	cp -r "${dir}/perfects/tetromino_puzzle_constraint.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"

	cd "${dir}/student_solution_envs/${student}-student-marking-env/"
	echo "\"${student}\": started tc test at $(date)"
	tc_output=$(timeout 900 python3 "autograder_tc.py" 2>&1)
	cd "${dir}"
	tc_mark=$(echo "${tc_output}" | grep "Total Grade - TC:" | cut -d " " -f5)
	tc_output=$(echo "${tc_output}" | grep -v "Total Grade - TC:")


	# tetromino_puzzle_constraint testing.
	echo "\"${student}\": Running tests on \"tetromino_puzzle_constraint.py\"."
	if [ -e "${dir}/student_solutions/${student}/tetromino_puzzle_constraint.py" ];then
		cp -r "${dir}/student_solutions/${student}/tetromino_puzzle_constraint.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	else
		cp -r "${dir}/blanks/tetromino_puzzle_constraint.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	fi

	cp -r "${dir}/perfects/csp_algorithms.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"
	cp -r "${dir}/perfects/tetris_csp.py" "${dir}/student_solution_envs/${student}-student-marking-env/csp/"

	cd "${dir}/student_solution_envs/${student}-student-marking-env/"
	echo "\"${student}\": started tpc test at $(date)"
	tpc_output=$(timeout 900 python3 "autograder_tpc.py" 2>&1)
	cd "${dir}"
	tpc_mark=$(echo "${tpc_output}" | grep "Total Grade - TPC:" | cut -d " " -f5)
	tpc_output=$(echo "${tpc_output}" | grep -v "Total Grade - TPC:")


	# Final Mark Calculations and Documentation.
	numerator=$(echo "$(echo ${ca_mark} | cut -d"/" -f1) + $(echo ${tc_mark} | cut -d"/" -f1) + $(echo ${tpc_mark} | cut -d"/" -f1)" | bc)
	denominator="28"
	total_mark="Total Grade: ${numerator}/${denominator}"

	echo "\"${student}\": Documenting student mark."
	echo -e "${ca_output}\n${tc_output}\n${tpc_output}\n\n${total_mark}" > "${dir}/student_marks/${student}-autograder-mark.txt"

	rm -rf 	"${dir}/student_solution_envs/${student}-student-marking-env"
	echo "\"${student}\": Marking Done.") &
	pids="$pids $!"

done

wait $pids

rm -rf "${dir}/student_solution_envs"

echo -e "\n\nMarking Done."
