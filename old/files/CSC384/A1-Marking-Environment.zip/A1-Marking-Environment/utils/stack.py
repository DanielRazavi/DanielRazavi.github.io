from collections import deque

class Stack:

  visited = []
  seen = []

  def __init__(self):
    self._items = deque()

  def empty(self):
    return len(self._items) == 0

  def push(self, item):
    # Stack.seen.append(item)
    self._items.append(item)

  def pop(self):
    popped_item = self._items.pop()
    # Stack.visited.append(popped_item)
    return popped_item

"""
Dan's Notes:

Maybe tracking the visited from Stack isn't a good idea cuz the "item" could be
in any format like a tuple inside a list, or a list, or a tuple, or a string,
literally any format.

Maybe look into tracking it through GameStateHandler() if you can. Idk every
time get_successors() is ran, add the main state to the "visited" and the
successors + main state to "seen".

"""
