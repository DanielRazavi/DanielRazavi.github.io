from state import GameState, GameStateHandler
from state_searching import *
from grade_helpers import load_test, verify, pseudo_simulate, check_solution
import signal

COST_FUNCTIONS = [lambda pos: 0.2 ** pos[0], lambda pos: pos[0] * 2,
                  lambda pos: pos[1] * 2, lambda pos:  pos[1] * 2 + 0.2 ** pos[0]]


def test(tests, tester):

    def signal_handler(signum, frame):
        raise TimeoutError("Timed out!")

    total_marks, earned_marks = 0, 0

    for test in tests:
        name, map_file, goal_func, solution, visited, seen = load_test(test)

        total_marks += 1
        signal.signal(signal.SIGALRM, signal_handler)
        signal.alarm(30)

        try:
            state = GameState(map_file)

            result = tester(goal_func, state, solution, visited, seen)

            earned = int(result)
            print("Testing: {}\t [{}/{}]".format(name, earned, 1))

            earned_marks += earned
        except NotImplementedError as e:
            print("Testing: {}\t [{}]\t [0/1]".format(name, e))
        except TimeoutError:
            print("Testing: {}\t [Timed Out]\t [0/1]".format(name))
        except Exception as e:
            print(
                "Testing: {}\t [Raised an Exception: {}]\t [0/1]".format(name, e))
    return earned_marks, total_marks


if __name__ == "__main__":
    total_marks, earned_marks = 0, 0

    print("\n------ Question 5 ------")
    e, t = test(["astar/two_switches_1", "astar/two_switches_2", "astar/two_switches_3", "astar/two_switches_4", "astar/two_switches_5"],
                lambda goal, state, solution, visited, seen:
                pseudo_simulate(SearchAlgorithms.a_star_search(goal, state, heuristic=Heuristics.two_boxes_heuristic), solution, state, goal, visited, "<blank>"))
    total_marks += t
    earned_marks += e

    print("\n------ Question 6 ------")
    e, t = test(["astar/no_boxes_1", "astar/no_boxes_2", "astar/no_boxes_3", "astar/no_boxes_4", "astar/no_boxes_5"],
                lambda goal, state, solution, visited, seen:
                pseudo_simulate(SearchAlgorithms.a_star_search(goal, state, heuristic=Heuristics.points_only_heuristic), solution, state, goal, visited, "<blank>"))
    total_marks += t
    earned_marks += e

    print("\n\nTotal Grade - Hueristics: {}/{}".format(earned_marks, total_marks))
